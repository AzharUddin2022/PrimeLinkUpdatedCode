﻿namespace PrimLink.Helper
{
    public class CacheConnectionString
    {
        public string DefaultConnection { get; set; }
    }
}
